import re

if __name__ == '__main__' :
    with open('sys_write_log.log','r') as syscall :
        total_byte = 0 
        for line in syscall.readlines():
            m = re.match('^(.*.sst) (.*) (\d*)$',line)
            if m:
                file_name = m.group(1)
                operation = m.group(2)
                size = m.group(3)
                total_byte += int(size)
        print('syscall write size : ' + str(total_byte))

    with open('table_fs_put_log.log','r') as leveldb_write :
        total_byte = 0 
        for line in leveldb_write.readlines():
            m = re.match('^Put key: (\d*) value: (\d*)$',line)
            if m:
                key_size = int(m.group(1))
                value_size = int(m.group(2))
                total_byte += (key_size + value_size)
        print('levelDB put size :' + str(total_byte))

