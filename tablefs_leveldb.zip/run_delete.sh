#fusermount -u mount_dir
rm -rf metadir/meta/*
rm -rf datadir/*
rm -rf secdir/
mkdir secdir
#rm *.log
#src/tablefs -mountdir mount_dir -metadir metadir -datadir datadir -secondary_dir metadir/meta
