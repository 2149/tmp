import re
begin_line = 0# 32556099
if __name__ == '__main__' :
    cnt = 0
    mmap_cnt = 0
    adaptor_cnt = 0
    for line in open('log_log.log'):
        if cnt >= begin_line :
            m = re.match('^.*162]- mmap (\d*)$',line)
            m2 = re.match('^.*127]- Adaptor Get : 16 (\d*)$',line)
            m3 =re.match('^.*82]- fread_unlocked (\d*)$',line)
            m4 =re.match('^.*1034]- ReadDir over: count \d* , (\d*)$',line)
            if m :
                mmap_cnt += int(m.group(1))
            if m2:
                #adaptor_cnt += int(m2.group(1))
                pass
            if m3:
                #mmap_cnt+= int(m3.group(1))
                pass
            if m4:
                adaptor_cnt += int(m4.group(1))
                #mmap_cnt += int(m3.group(1))
            #print('line ' + str(cnt))
        cnt = cnt + 1
    print('mmap read size :'+str(mmap_cnt))
    print('get size :' + str(adaptor_cnt))
    print('RA : '+ str(1.0*mmap_cnt / adaptor_cnt))


    
