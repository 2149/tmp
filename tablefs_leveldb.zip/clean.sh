#pkill -9 fs_main
#!/bin/sh
#dirpath=/home/ka2149/Documents/fs/srofs/testdir
dirpath=/home/2149/fs/srofs/testdir
fusermount -u $dirpath/mountdir 

