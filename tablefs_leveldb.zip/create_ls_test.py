import os
import sys 
import random
import string

root_dir = os.path.join(os.getcwd(),'mount_dir')
dir_num = 10
total_file_num = 5000000 
file_size_range = range(512,4096)

def get_random_string(size ):
    ans = ''
    for i in range(0,size) :
        ans = ans +random.choice(string.ascii_letters + string.digits)
    return ans

def create_file(name,size):
    fp = open(os.path.join(os.getcwd(),name ),'w')
    fp.write(get_random_string(size))
    fp.close()



if __name__ == '__main__':
    file_num = total_file_num / dir_num
    for i in range(0,dir_num):
        new_path =os.path.join(root_dir,str(i)) 
        if not os.path.exists(new_path):
            os.mkdir(new_path)
    current_no = 0
    for j in range(0,total_file_num):
        new_path = os.path.join(root_dir,str(current_no%dir_num))
        os.chdir(new_path)
        rand_size = random.choice(file_size_range)
        while True:
            if not os.path.exists(str(current_no)) :
                break
            else :
                current_no = current_no +1
        create_file(str(current_no),rand_size)
        if j % (int(total_file_num/100)) == 0 :
                print("% "+ str(j //(total_file_num//100)))
        #os.chdir('..')
            
