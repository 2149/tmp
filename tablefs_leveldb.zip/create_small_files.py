import os 
import sys
import random
import string

max_dir_depth = 10
file_max_size = 4096
#total_file_size = 50 * 1024 *1024 *2014
total_file_size = 1*1024*1024*1024
sub_dir_brach = range(1,1000)
sub_file_number = range(1,1000)
root_dir = '/home/kevin/tablefs-0.3/mount_dir'

def get_random_string(size ):
    ans = ''
    for i in range(0,size) :
        ans = ans +random.choice(string.ascii_letters + string.digits)
    return ans


def create_file(name , size ):
    fp = open(os.path.join(os.getcwd() ,name),'w')
    fp.write(get_random_string(size))
    fp.close()

def construct( depth ,remain_size , path ):
    if remain_size <= 0 :
         return 
    if depth >= max_dir_depth : # max depth
        file_dir_ratio = 1.0
    else :
        file_dir_ratio = 1.0* depth / max_dir_depth
    dir_size =  int(remain_size * (1- file_dir_ratio))
    file_size = remain_size - dir_size
    os.chdir(path)
    #create subdirs 
    dir_no = 0 
    while True :
        if dir_size <=0 :
            break
        rand_size = random.choice(range(4096,dir_size+1)) if dir_size > 4096 else dir_size
        new_path  = os.path.join(path,str(dir_no))
        if os.path.exists(new_path) :
            dir_no+= 1
            continue
        os.mkdir(new_path)
        construct(depth+1 , rand_size , new_path)
        os.chdir(path)
        dir_no += 1
        dir_size -= rand_size
    #create files
    os.chdir(path)
    file_no = 0
    while True :
        if file_size <= 0 :
            break
        rand_size = random.choice(range(0,4096))
        new_file_name = 'file_' +str(file_no) + '.txt'
        if os.path.exists(new_file_name):
            file_no+= 1
            continue
        create_file('file_'+str(file_no)+'.txt',rand_size)
        file_size-=rand_size 
        file_no += 1



    



if __name__ == '__main__':
    construct(0,total_file_size,root_dir)

    

