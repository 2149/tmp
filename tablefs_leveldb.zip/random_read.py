import os
import random

mount_dir = 'mount_dir'
file_range = range(0,4000000)

dir_num = 8
file_num = 500000

if __name__ == '__main__':
    for i in range(0,file_num):
        file_no = random.choice(file_range)
        file_dir = file_no % dir_num
        with  open(mount_dir + '/' + str(file_dir) + '/' + str(file_no),'r') as f:
            lines = f.readlines()
            f.close()
            print('file '+str(file_no) + 'size : '+ str(len(lines)))




