fusermount -u mount_dir
#rm -rf metadir/meta/*
#rm -rf datadir/*
#rm -rf secdir/
#mkdir secdir
#rm *.log
dirpath=/mnt/sdb/2149
rm -rf /mnt/sdb/2149/metadir
rm -rf /mnt/sdb/2149/datadir
mkdir /mnt/sdb/2149/metadir
mkdir /mnt/sdb/2149/datadir

#rm -rf /mnt/sdb/2149/metadir/*
#rm -rf /mnt/sdb/2149/datadir/*

#dirpath=/home/czl/pmem0/testdir
src/tablefs -mountdir mount_dir -metadir $dirpath/metadir -datadir $dirpath/datadir  -secondary_dir $dirpath/metadir 
