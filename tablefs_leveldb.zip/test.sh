
for i in {1..9}
do
	./run_delete.sh
	./create_random_files 1${i}00000 1000000
	./run.sh
	ls mount_dir/ -l | wc -l
	python compute_ra.py > ra1_${i}.txt
	du metadir/meta/ -m > size1_${i}.txt
	echo $i over 
done
