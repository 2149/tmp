Compile:
  make tablefs

Run:
  ./tablefs -mountdir [MOUNT DIR] -metadir [METADATA DIR] -datadir [DATA DIR]
