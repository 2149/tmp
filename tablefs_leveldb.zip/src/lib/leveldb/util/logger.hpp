
/**
 * @file logger.hpp
 * @brief 
 * @author kevin20x2@gmail.com
 * @version 1.0
 * @date 2019-01-05
 */
#pragma once
#include <sys/stat.h>
#include <string>
#include <cassert>
#include <mutex>

namespace kvfs
{

//#ifdef NDEBUG
//#define KVFS_ROCKS_LOG(...)  
//#else 
class KVFSLoggerInRocksDB {
    public:
    static KVFSLoggerInRocksDB * GetInstance();
    void Log(const char *file_name,int line ,const char * data ,  ...);
    protected:
    KVFSLoggerInRocksDB() :
        logfile_name("/home/hustkevin/tablefs-leveldb/log_log.log")
    {
        fp = fopen(logfile_name.c_str(),"w");
		fprintf(fp,"log inited .. ");
        assert(fp);

    };
    std::string logfile_name;
    FILE * fp;
	std::mutex mutex_;


    static KVFSLoggerInRocksDB * instance_;
};

#define KVFS_ROCKS_LOG(...) kvfs::KVFSLoggerInRocksDB::GetInstance()->Log(__FILE__,__LINE__,__VA_ARGS__)

//#endif // NDEBUG


}

