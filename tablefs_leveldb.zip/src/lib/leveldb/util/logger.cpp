#include "logger.hpp"
#include <sys/time.h>
#include <cstring>
#include <sys/stat.h>
#include <cstdarg>

namespace kvfs
{

//#ifndef NDEBUG
KVFSLoggerInRocksDB * KVFSLoggerInRocksDB :: instance_ = nullptr;

KVFSLoggerInRocksDB * KVFSLoggerInRocksDB :: GetInstance()
{
//    if(instance_ == nullptr)
 //   {
   //     instance_ = new KVFSLoggerInRocksDB();
   // }
    static KVFSLoggerInRocksDB local_s ;
    return &local_s;
}

static char * GetCurrentTime()
{
    static char buffer[100];
    struct timeval tv;
    struct timezone tz;
    struct tm * t;

    gettimeofday(&tv,&tz);
    t = localtime(&tv.tv_sec);

    sprintf(buffer, "%d-%d-%d:%d:%d:%d@%ld",1900+t->tm_year,1+t->tm_mon,t->tm_mday,
            t->tm_hour,t->tm_min,t->tm_sec,tv.tv_usec);
    return buffer;

}

void KVFSLoggerInRocksDB :: Log(const char * file_name ,int line, const char * data,  ...)
{
	mutex_.lock();
    va_list ap;
    va_start(ap,data);
    //std::cout << data << std::endl;
    fprintf(fp,"%s[%s : %d]- ",GetCurrentTime(),file_name ,line);
    vfprintf(fp,data,ap);
    int len = strlen(data);
    if(data[len-1] != '\n')
        fprintf(fp,"\n");
    fflush(fp);
	mutex_.unlock();
}
//#endif // NDEBUG


}
