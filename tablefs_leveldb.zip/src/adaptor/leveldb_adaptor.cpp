/*
 * LevelDBAdaptor.cpp
 *
 *  Created on: Jul 19, 2011
 *      Author: kair
 */

#include "leveldb_adaptor.h"
#include "leveldb/db.h"
#include "leveldb/cache.h"
#include "leveldb/write_batch.h"
#include "leveldb/status.h"
#include "leveldb/filter_policy.h"
#include "leveldb/write_batch_internal.h"
#include <time.h>
#include <fstream>

#include "util/logger.hpp"

using namespace leveldb;

namespace tablefs {

class PutLogger 
{
    public :
    static void Log(const std::string  & data);
    virtual ~PutLogger() { ofs_.close();};
    protected:
    PutLogger():
        file_name_("/home/kevin/tablefs-0.3/table_fs_put_log.log")
    {
        ofs_.open(file_name_,std::ios::app);
    }
    static PutLogger * instance_;
    std::string file_name_;
    std::ofstream ofs_;
};

PutLogger * PutLogger :: instance_ = nullptr;
void PutLogger :: Log(const std::string  & data)
{
    if(instance_ == nullptr)
    {
        instance_ = new PutLogger();
    }
    instance_->ofs_ << data  <<std::endl;
}




LevelDBAdaptor::LevelDBAdaptor() :
  db_(NULL), cache_(NULL), logs(NULL), writeahead(true) {
}

LevelDBAdaptor::~LevelDBAdaptor() {
}

int LevelDBAdaptor::Init() {
  assert(db_ == NULL);
  int F_cache_size = p_.getPropertyInt("leveldb.cache.size", 64<<20);
  cache_ = (F_cache_size >= 0) ? leveldb::NewLRUCache(F_cache_size) : NULL;
  db_name = p_.getProperty("leveldb.db", "/tmp/db");
  Options options;
  options.compression = kSnappyCompression;
  options.create_if_missing =
    p_.getPropertyBool("leveldb.create.if.missing.db", true);
  options.block_cache = cache_;
  options.block_size =
    p_.getPropertyInt("leveldb_block_size", 4 << 10);
  options.write_buffer_size =
    p_.getPropertyInt("leveldb_write_buffer_size", 64<<20);
  options.max_open_files =
    p_.getPropertyInt("leveldb.max.open.files", 2048);
  options.filter_policy = NewBloomFilterPolicy(12);
  options.limit_sst_file_size =
    p_.getPropertyInt("leveldb_limit_sst_file_size", 2<<20);
  options.limit_level_zero=
    p_.getPropertyInt("leveldb_limit_level_zero", 10);
  options.factor_level_files=
    p_.getPropertyInt("leveldb_factor_level_files", 10);

  if (logs != NULL) {
    logs->LogMsg("limit level: %d\n", options.limit_sst_file_size);
    logs->LogMsg("limit level0: %d\n", options.limit_level_zero);
    logs->LogMsg("factor level files: %lf\n", options.factor_level_files);
  }

  options.secondary_dir = p_.getProperty("secondary_dir","");
  KVFS_ROCKS_LOG("options.secondary_dir %s", options.secondary_dir.c_str());

  options.max_dir_size = 2ull *1024 *1024*1024;

  writeahead = p_.getPropertyBool("leveldb.writeahead", true);
  logon = p_.getPropertyBool("leveldb.logon", false);
  sync_time_limit = p_.getPropertyInt("leveldb.sync.time.limit", 5);
  sync_size_limit = p_.getPropertyInt("leveldb.sync.size.limit", -1);
  last_sync_time = time(NULL);
  async_data_size = 0;
  Status s = DB::Open(options, db_name, &db_);
  if (!s.ok()) {
    return -1;
  } else {
    return 0;
  }
}

void LevelDBAdaptor::Cleanup() {
  delete db_;
  delete cache_;
  db_ = NULL;
}

int LevelDBAdaptor::Get(const leveldb::Slice &key,
                        std::string &result) {
  ReadOptions options;
  Status s = db_->Get(options, key, &result);
  if (logon) {
    if (logs != NULL) {
      const int *data = (const int *) key.ToString().data();
      logs->LogMsg("read %s %d %x\n", db_name.c_str(), data[0], data[1]);
    }
  }
  if(s.ok())
  {
	  KVFS_ROCKS_LOG("Adaptor Get : %d %d",key.size(),result.size());
  }
  if (!s.ok()) {
    result = s.ToString();
    return -1;
  } else {
    return (s.IsNotFound()) ? 0 : 1;
  }
}

LevelDBIterator* LevelDBAdaptor::GetNewIterator() {
  ReadOptions read_options;
  if (logon) {
    if (logs != NULL)
      logs->LogMsg("iterator\n");
  }
  Iterator* iter = db_->NewIterator(read_options);
  return new LevelDBIterator(iter);
}

int LevelDBAdaptor::Sync() {
  WriteOptions write_options;
  write_options.sync = true;
  leveldb::Status status = db_->Put(write_options, "sync", "");
  if (status.ok()) {
    return 0;
  } else {
    return -1;
  }
}

int LevelDBAdaptor::Put(const leveldb::Slice &key,
                        const leveldb::Slice &value) {

  PutLogger :: Log("Put key: " + std::to_string(key.size()) + " value: " + std::to_string(value.size()));
  if (logon) {
    if (logs != NULL) {
      const int *data = (const int *) key.ToString().data();
      logs->LogMsg("Put %d %x\n", data[0], data[1]);
    }
  }
  WriteOptions write_options;
  if (sync_size_limit > 0) {
    async_data_size += key.size() + value.size();
    if (async_data_size > sync_size_limit) {
      write_options.sync = true;
      async_data_size = 0;
    }
  } else
  if (sync_time_limit > 0) {
    time_t now = time(NULL);
    if (now - last_sync_time > sync_time_limit) {
      write_options.sync = true;
      last_sync_time = now;
    }
  }
  write_options.writeahead = writeahead;
  leveldb::Status status = db_->Put(write_options, key, value);
  if (status.ok()) {
    return 0;
  } else {
    if (logon) {
      if (logs != NULL) {
        logs->LogMsg("Put Error: %s\n", status.ToString().c_str());
      }
    }
    return -1;
  }
}

int LevelDBAdaptor::Delete(const leveldb::Slice &key) {
  PutLogger :: Log("Delete key: " + std::to_string(key.size()));
  if (logon) {
    if (logs != NULL) {
      const int *data = (const int *) key.ToString().data();
      logs->LogMsg("Delete %d %x\n", data[0], data[1]);
    }
  }
  WriteOptions write_options;
  db_->Delete(write_options, key);
  return 0;
}

int LevelDBAdaptor::Write(WriteBatch &batch) {
  PutLogger :: Log("WriteBatch size: " + std::to_string(WriteBatchInternal :: ByteSize(&batch)));
  WriteOptions write_options;
  Status s = db_->Write(write_options, &batch);
  if (!s.ok()) {
    return -1;
  }
  return 0;
}

void LevelDBAdaptor::Report() {
  std::string result;
  db_->GetProperty(leveldb::Slice("leveldb.stats"), &result);
  logs->LogMsg("\n%s\n", result.c_str());
}

void LevelDBAdaptor::Compact() {
  db_->CompactRange(NULL, NULL);
}

bool LevelDBAdaptor::GetMetric(std::string* value) {
  return db_->GetProperty(Slice("leveldb.stats"), value);
}

}
