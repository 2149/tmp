#!/bin/sh
dirpath=/home/czl/sdb/testdir
#dirpath=/home/czl/pmem0/testdir
rm -rf $dirpath/datadir/*
#rm /home/czl/pmem0/aepdir/*
rm -rf $dirpath/metadir/*


