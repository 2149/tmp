#include <cstdio>
#include <unistd.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <string>
#include <time.h>

//#include <unordered_map>


void generate_random_string(char * buffer, int size)
{
	for(int i = 0;i<size;++i)
	{
		buffer[i] = rand()%256; 
	}
}


int main(int argc , char * argv[])
{

	int total_file ;
	int dir_num ; 
	if(argc < 3 )
	{
		printf("lack args..");
		return -1;
	}
	total_file = atoi(argv[1]);
	dir_num = atoi(argv[2]);

	char pwd_buff[4096];
	char write_buffer[4096];
	
	char * current_dir = getcwd(pwd_buff,4096);
	std::string root_dir = std::string(current_dir) + "/" + "mount_dir/";
	srand(time(nullptr));

	for(int i = 0;i< dir_num ;++i)
	{
		int ans = mkdir((root_dir + std::to_string(i)).c_str(),0777);
	}

	for(int i = 0 ;i< total_file ;++i)
	{
		int current_dir = i % dir_num;
		std::string file_path = root_dir + std::to_string(current_dir) + "/" + std::to_string(i);
		int fd = open(file_path.c_str(),O_RDWR | O_CREAT,0600);
		int rand_size = rand() %(4096-512) + 512 ;
		generate_random_string(write_buffer,rand_size);
		write(fd,write_buffer,rand_size);
		close(fd);
		if(i %(total_file/100) == 0)
		{
			printf("%%%d\n",i/(total_file/100));
		}
	}


	return 0;
}
